const result = require('./2022_11_17_모듈 2');

console.log( result );
console.log( result() );
// { add : fuction } 이 형태로 넘어 왔을 때는
// console.log( add.add() ); 라는 형태를 사용해야함