const a = 1;
const b = 3;


module.exports = {
    a,
    b,
};
module.exports = array;